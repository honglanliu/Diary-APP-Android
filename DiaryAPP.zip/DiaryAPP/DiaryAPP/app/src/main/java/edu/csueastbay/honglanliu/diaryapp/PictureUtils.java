package edu.csueastbay.honglanliu.diaryapp;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;

/**
 * Created by liuhonglan on 2017/11/22.
 */

public class PictureUtils {
    public static Bitmap getScaledBitMap(String path, int destWidth, int destHeight){
        //read in the dimensions of the image on disk
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);

        float srcWidth = options.outWidth;
        float srcHeight = options.outHeight;

        //figure out how much to scale down by
        int inSampelSize = 1;
        if(srcWidth > destWidth || srcHeight > destHeight){
            float widthScale = srcWidth / destWidth;
            float heightScale = srcHeight / destHeight;
            inSampelSize = Math.round(heightScale > widthScale ? heightScale : widthScale);
        }
        options = new BitmapFactory.Options();
        options.inSampleSize = inSampelSize;

        //read in and create final bitmap
        return BitmapFactory.decodeFile(path, options);
    }

    //check how big the screen is and then scales the image down to that size
    public static Bitmap getScaledBitmap(String path, Activity activity){
        Point size = new Point();
        activity.getWindowManager().getDefaultDisplay().getSize(size);
        return getScaledBitMap(path, size.x, size.y);
    }
}
