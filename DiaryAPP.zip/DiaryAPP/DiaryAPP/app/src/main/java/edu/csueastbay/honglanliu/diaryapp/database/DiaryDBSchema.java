package edu.csueastbay.honglanliu.diaryapp.database;

/**
 * Created by liuhonglan on 2017/11/21.
 */

public class DiaryDBSchema {
    public static final class DiaryTable{
        public static final String NAME = "diaries";
        public static final class Coloums{
            public static final String UUID = "uuid";
            public static final String TITLE = "title";
            public static final String DETAILS = "details";
            public static final String DATE = "date";
        }
    }
}
