package edu.csueastbay.honglanliu.diaryapp;

import android.support.v4.app.Fragment;

/**
 * Created by liuhonglan on 2017/10/27.
 */

public class DiaryListActivity extends SingleFragmentActivity {
    @Override
    protected Fragment createFragment(){
        return new DiaryListFragment();
    }
}