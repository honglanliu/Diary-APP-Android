package edu.csueastbay.honglanliu.diaryapp;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;


import java.util.UUID;

public class DiaryActivity extends SingleFragmentActivity {
    public static final String EXTRA_DIARY_ID = "edu.csueastbay.honglanliu.diaryapp.diary_id";
    @Override
    protected Fragment createFragment(){
        UUID diaryId = (UUID)getIntent().getSerializableExtra(EXTRA_DIARY_ID);
        return DiaryFragment.newInstance(diaryId);
    }
    public static Intent newIntent(Context packageContext, UUID diaryId){
        Intent intent = new Intent(packageContext, DiaryActivity.class);
        intent.putExtra(EXTRA_DIARY_ID, diaryId);
        return intent;
    }
}