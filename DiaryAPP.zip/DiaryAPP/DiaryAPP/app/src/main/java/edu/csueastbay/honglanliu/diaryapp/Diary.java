package edu.csueastbay.honglanliu.diaryapp;

import java.util.Date;
import java.util.UUID;

/**
 * Created by liuhonglan on 2017/10/27.
 */

public class Diary {
    private UUID mID;
    private String mTitle;
    private String mDetails;
    private Date mDate;

    public Diary(){
        //mID = UUID.randomUUID();
        //mDate = new Date();
        this(UUID.randomUUID());
    }

    public Diary(UUID uuid){
        mID = uuid;
        mDate = new Date();
    }

    public UUID getID() {
        return mID;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getDetails() {
        return mDetails;
    }

    public void setDetails(String details) {
        mDetails = details;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }

    public String getPhotoFileName(){
        return "IMG_" + getID().toString() + ".jpg";
    }
}
