package edu.csueastbay.honglanliu.diaryapp.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.Date;
import java.util.UUID;

import edu.csueastbay.honglanliu.diaryapp.database.DiaryDBSchema.DiaryTable;
import edu.csueastbay.honglanliu.diaryapp.Diary;

/**
 * Created by liuhonglan on 2017/11/21.
 */

public class DiaryCursorWrapper extends CursorWrapper{
    public DiaryCursorWrapper(Cursor cursor){
        super(cursor);
    }
    public Diary getDiary(){
        String uuidString = getString(getColumnIndex(DiaryTable.Coloums.UUID));
        String title = getString(getColumnIndex(DiaryTable.Coloums.TITLE));
        long date = getLong(getColumnIndex(DiaryTable.Coloums.DATE));
        String details = getString(getColumnIndex(DiaryTable.Coloums.DETAILS));

        Diary diary = new Diary(UUID.fromString(uuidString));
        diary.setTitle(title);
        diary.setDate(new Date(date));
        diary.setDetails(details);

        return diary;
    }
}
