package edu.csueastbay.honglanliu.diaryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import edu.csueastbay.honglanliu.diaryapp.database.DiaryBaseHelper;
import edu.csueastbay.honglanliu.diaryapp.database.DiaryCursorWrapper;
import edu.csueastbay.honglanliu.diaryapp.database.DiaryDBSchema.DiaryTable;
/**
 * Created by liuhonglan on 2017/10/27.
 */

public class DiaryLab {
    private static DiaryLab sDiaryLab;
    //private List<Diary> mDiaries;
    private Context mContext;
    private SQLiteDatabase mDatabase;

    public static DiaryLab get(Context context){
        if(sDiaryLab == null)
            sDiaryLab = new DiaryLab(context);
        return sDiaryLab;
    }
    private DiaryLab(Context context){
        mContext = context.getApplicationContext();
        mDatabase = new DiaryBaseHelper(mContext).getWritableDatabase();

        //mDiaries = new ArrayList<>();
          /*for(int i = 0; i < 10; i++){
            Diary diary = new Diary();
            diary.setTitle("Diary #" + i);
            mDiaries.add(diary);
        }*/

    }

    public void addDiary(Diary d){
        //mDiaries.add(d);
        ContentValues values = getContentValues(d);
        mDatabase.insert(DiaryTable.NAME, null, values);
    }

    public List<Diary> getDiaries() {
        //return mDiaries;
        List<Diary> diaries = new ArrayList<>();
        DiaryCursorWrapper cursor = queryDiaries(null, null);
        try{
            cursor.moveToFirst();
            while (!cursor.isAfterLast()){
                diaries.add(cursor.getDiary());
                cursor.moveToNext();
            }
        }finally {
            cursor.close();
        }
        return diaries;
    }

    public Diary getDiary(UUID id){
        /*for(Diary diary : mDiaries){
            if(diary.getID().equals(id))
                return diary;
        }*/
        DiaryCursorWrapper cursor = queryDiaries(DiaryTable.Coloums.UUID + " = ?", new String[] {id.toString()});
        try{
            if(cursor.getCount() == 0)
                return null;
            cursor.moveToFirst();
            return cursor.getDiary();
        }finally {
            cursor.close();
        }
    }

    public File getPhotoFile(Diary diary){
        File filesDir = mContext.getFilesDir();
        return new File(filesDir, diary.getPhotoFileName());
    }

    public void updateDiary(Diary diary){
        String uuidString = diary.getID().toString();
        ContentValues values = getContentValues(diary);
        mDatabase.update(DiaryTable.NAME, values, DiaryTable.Coloums.UUID + " = ?", new String[]{ uuidString });
    }

    private DiaryCursorWrapper queryDiaries(String whereClause, String[] whereArgs){
        Cursor cursor = mDatabase.query(
                DiaryTable.NAME,
                null,//columns-null means select all columns
                whereClause,
                whereArgs,
                null,
                null,
                null
        );
        return new DiaryCursorWrapper(cursor);
    }

    private static ContentValues getContentValues(Diary diary){
        ContentValues values = new ContentValues();
        values.put(DiaryTable.Coloums.UUID, diary.getID().toString());
        values.put(DiaryTable.Coloums.TITLE, diary.getTitle());
        values.put(DiaryTable.Coloums.DATE, diary.getDate().getTime());
        values.put(DiaryTable.Coloums.DETAILS, diary.getDetails());
        return values;
    }
}